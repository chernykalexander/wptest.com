<?php
/*
Plugin Name: my-ads
Plugin URI: http://www.robotstxt.org/
Description: Плагин добавляет блоки рекламы
Version: 1.0
Author: Alexander Chernykh
Author URI: http://htaccess.net.ru/
License: GPLv2
*/



// Эта функция выполняется при активации плагина во вкладке Плагины WordPress.
// Она принимает два параметра: 
// 1. путь к основному файлу плагина 
// 2. функцию для выполнения после его активации.
register_activation_hook( __FILE__ , 'my_ads_install' );

function my_ads_install() {

	// Функция использует глобальную переменную $wp_version,
	// которая хранит информацию об используемой в данный момент версии WordPress
	// и подтверждает, что она не ниже версии 3.5. Сравнение версий осуществляется
	// с помощью функции РНР version_compare().	
	global $wp_version;
	
	if ( version_compare( $wp_version, '3.5', '<' ) ) {
		wp_die( 'Для данного плагина WordPress нужна версия 3.5 или выше.' );
	};
};



// Функция, которая выполняется, когда плагин деактивирован.
register_deactivation_hook( FILE , 'my_ads_deactivate()' );

function my_ads_deactivate() {
	// делаем то, что нужно
};



// Создаем произвольное меню для плагина
// Сначала вызываем зацепку-действие admin_menu. 
// Эта зацепка запускается после создания базовой структуры меню панели администратора.
add_action( 'admin_menu', 'my_ads_create_menu' );

function my_ads_create_menu() {

	// Аргументы для add_menu_page
	// pagetitle — текст, используемый для названия HTML (между тегами <title>).
	// menu_title — текст, используемый как имя пункта меню в консоли.
	// capability — минимальные права пользователя, позволяющие видеть меню.
	// menu_slug — уникальное слаг-имя меню.
	// function — отображает контент страницы настроек меню.
	// icon_url — путь к произвольной иконке меню (по умолчанию images/generic.png).
	// position — порядок отображения в меню. По умолчанию будет отображаться в конце структуры меню.

	// создаем новое меню верхнего уровня
	add_menu_page( 
		'Страница плагина my-ads', 
		'Плагин my-ads',
		'manage_options', 
		'my_ads_slug', 
		'my_ads_main_plugin_page',
		plugins_url( '/images/icon_my_signature.png', __FILE__ )
	 );

	
	// создаем подпункты меню: настройка и поддержка
	add_submenu_page( 
		'my_ads_slug', 
		'Страница настроек плагина my-signature',
		'Настройки', 
		'manage_options', 
		'my_ads_settings_slug',
		'my_ads_settings_page' 
	);

	add_submenu_page( 
		'my_ads_slug', 
		'Страница техподдержки плагина my-signature',
		'Техподдержка', 
		'manage_options', 
		'my_ads_support_slug', 
		'my_ads_support_page' 
	);
};

